<?php
session_start();
if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit();
}
include "conexion.php";

$id_usuario = $_SESSION["id_usuario"];
$rol = $_SESSION["rol"];

if ($rol == "admin") {
    $sql = "SELECT r.*, u.nombre AS usuario, rc.nombre AS recurso
            FROM reservas r
            JOIN usuarios u ON r.id_usuario = u.id_usuario
            JOIN recursos rc ON r.id_recurso = rc.id_recurso
            ORDER BY r.fecha DESC, r.hora_inicio DESC";
    $stmt = $conn->prepare($sql);
} else {
    $sql = "SELECT r.*, u.nombre AS usuario, rc.nombre AS recurso
            FROM reservas r
            JOIN usuarios u ON r.id_usuario = u.id_usuario
            JOIN recursos rc ON r.id_recurso = rc.id_recurso
            WHERE r.id_usuario = ?
            ORDER BY r.fecha DESC, r.hora_inicio DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_usuario);
}
$stmt->execute();
$result = $stmt->get_result();

$titulo = "Reservas";
include "includes/header.php";
?>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <h2 class="mb-0 fw-bold"><i class="bi bi-calendar3 me-2 text-primary"></i>Reservas</h2>
    <a href="reserva_nueva.php" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i>Nueva reserva
    </a>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th class="d-none d-md-table-cell">Usuario</th>
                        <th>Recurso</th>
                        <th>Fecha</th>
                        <th class="d-none d-sm-table-cell">Horario</th>
                        <th>Estado</th>
                        <th class="text-end">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td class="text-muted"><?php echo $row["id_reserva"]; ?></td>
                            <td class="d-none d-md-table-cell"><?php echo htmlspecialchars($row["usuario"]); ?></td>
                            <td class="fw-semibold"><?php echo htmlspecialchars($row["recurso"]); ?></td>
                            <td><?php echo $row["fecha"]; ?></td>
                            <td class="d-none d-sm-table-cell text-muted" style="font-size:.85rem">
                                <?php echo substr($row["hora_inicio"], 0, 5); ?> – <?php echo substr($row["hora_fin"], 0, 5); ?>
                            </td>
                            <td>
                                <?php
                                $badge = match ($row["estado"]) {
                                    "confirmada" => "success",
                                    "pendiente"  => "warning",
                                    "cancelada"  => "danger",
                                    default      => "secondary"
                                };
                                ?>
                                <span class="badge bg-<?php echo $badge; ?>"><?php echo ucfirst($row["estado"]); ?></span>
                            </td>
                            <td class="text-end">
                                <?php if ($rol == "admin" || $row["id_usuario"] == $id_usuario): ?>
                                    <a href="reserva_editar.php?id=<?php echo $row["id_reserva"]; ?>"
                                        class="btn btn-sm btn-outline-primary me-1">
                                        <i class="bi bi-pencil"></i><span class="d-none d-sm-inline ms-1">Editar</span>
                                    </a>
                                    <a href="reserva_eliminar.php?id=<?php echo $row["id_reserva"]; ?>"
                                        class="btn btn-sm btn-outline-danger"
                                        onclick="return confirm('¿Seguro que deseas cancelar esta reserva?');">
                                        <i class="bi bi-trash"></i><span class="d-none d-sm-inline ms-1">Eliminar</span>
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include "includes/footer.php"; ?>