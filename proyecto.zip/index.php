<?php
session_start();

if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit();
}


$titulo = "Panel principal";
include "includes/header.php";
?>

<div class="mb-4">
    <h2 class="fw-bold"><i class="bi bi-grid me-2 text-primary"></i>Panel principal</h2>
    <p class="text-muted">Bienvenido, <?php echo htmlspecialchars($_SESSION["nombre"]); ?></p>
</div>

<div class="row g-3">
    <div class="col-12 col-md-4">
        <div class="card h-100">
            <div class="card-body text-center py-4">
                <i class="bi bi-tags fs-1 text-primary mb-3 d-block"></i>
                <h4 class="fw-bold">Categorías</h4>
                <p class="text-muted">Gestiona los tipos de recursos.</p>
                <a href="categorias.php" class="btn btn-primary w-100">
                    <i class="bi bi-arrow-right-circle me-1"></i>Gestionar
                </a>
            </div>
        </div>
    </div>

    <?php if ($_SESSION["rol"] == "admin"): ?>
    
    <?php endif; ?>

    <div class="col-12 col-md-4">
        <div class="card h-100">
            <div class="card-body text-center py-4">
                <i class="bi bi-box-seam fs-1 text-primary mb-3 d-block"></i>
                <h4 class="fw-bold">Recursos</h4>
                <p class="text-muted">Administra los recursos reservables.</p>
                <a href="recurso.php" class="btn btn-primary w-100">
                    <i class="bi bi-arrow-right-circle me-1"></i>Gestionar
                </a>
            </div>
        </div>
    </div>

    <div class="col-12 col-md-4">
        <div class="card h-100">
            <div class="card-body text-center py-4">
                <i class="bi bi-calendar3 fs-1 text-primary mb-3 d-block"></i>
                <h4 class="fw-bold">Reservas</h4>
                <p class="text-muted">Crea y revisa reservas.</p>
                <a href="reserva.php" class="btn btn-primary w-100">
                    <i class="bi bi-arrow-right-circle me-1"></i>Gestionar
                </a>
            </div>
        </div>
    </div>
    <div class="col-12 col-md-4">
       <?php if ($_SESSION["rol"] == "admin"): ?>
    <div class="card h-100">
            <div class="card-body text-center py-4">
                <i class="bi bi-person-gear fs-1 text-primary mb-3 d-block"></i>
                <h4 class="fw-bold">Gestión de Usuarios</h4>
                <p class="text-muted">Crea y revisa usuarios.</p>
                <a href="usuarios.php" class="btn btn-primary w-100">
                    <i class="bi bi-arrow-right-circle me-1"></i>Gestionar
                </a>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="mb-4">

        <a href="usuario_perfil.php" class="btn btn-outline-primary">
            <i class="bi bi-person-circle me-1"></i> Editar mi perfil
        </a>
    </div>
</div>

<?php include "includes/footer.php"; ?>