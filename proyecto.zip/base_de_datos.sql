-- ============================================================
--  CREACIÓN DE LA BASE DE DATOS
-- ============================================================

CREATE DATABASE IF NOT EXISTS sistema_reservas;
USE sistema_reservas;


-- ============================================================
--  TABLA: USUARIOS
-- ============================================================

CREATE TABLE usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    rol ENUM('admin','usuario') DEFAULT 'usuario'
);

-- Insertamos usuarios reales
INSERT INTO usuarios (nombre, email, password, rol) VALUES
('Administrador General', 'admin@sistema.com', 'admin123', 'admin'),
('Daniel Pérez', 'daniel.perez@gmail.com', 'user123', 'usuario'),
('Laura Gómez', 'laura.gomez@hotmail.com', 'user123', 'usuario'),
('Carlos Ruiz', 'carlos.ruiz@yahoo.es', 'user123', 'usuario');


-- ============================================================
--  TABLA: CATEGORÍAS
-- ============================================================

CREATE TABLE categorias (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT
);

-- Insertamos categorías reales
INSERT INTO categorias (nombre, descripcion) VALUES
('Aulas', 'Aulas de formación equipadas con proyector'),
('Salas de reuniones', 'Salas para reuniones internas o externas'),
('Equipos informáticos', 'Portátiles, PCs y material tecnológico'),
('Instalaciones deportivas', 'Pistas y espacios deportivos');


-- ============================================================
--  TABLA: RECURSOS
-- ============================================================

CREATE TABLE recursos (
    id_recurso INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    capacidad INT DEFAULT 1,
    estado ENUM('activo','inactivo') DEFAULT 'activo',
    id_categoria INT NOT NULL,
    FOREIGN KEY (id_categoria) REFERENCES categorias(id_categoria)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
);

-- Insertamos recursos reales
INSERT INTO recursos (nombre, descripcion, capacidad, estado, id_categoria) VALUES
('Aula 1', 'Aula con 30 puestos y proyector', 30, 'activo', 1),
('Aula 2', 'Aula con 25 puestos y pizarra digital', 25, 'activo', 1),
('Sala de reuniones A', 'Sala para 10 personas', 10, 'activo', 2),
('Sala de reuniones B', 'Sala para 6 personas', 6, 'activo', 2),
('Portátil HP ProBook', 'Portátil para uso docente', 1, 'activo', 3),
('PC de sobremesa Dell', 'Equipo de escritorio', 1, 'activo', 3),
('Pista de pádel', 'Pista exterior de pádel', 4, 'activo', 4),
('Pista de baloncesto', 'Pista cubierta', 10, 'activo', 4);


-- ============================================================
--  TABLA: RESERVAS
-- ============================================================

CREATE TABLE reservas (
    id_reserva INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_recurso INT NOT NULL,
    fecha DATE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    estado ENUM('pendiente','confirmada','cancelada') DEFAULT 'pendiente',
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
        ON DELETE CASCADE,
    FOREIGN KEY (id_recurso) REFERENCES recursos(id_recurso)
        ON DELETE CASCADE
);

-- Insertamos reservas reales SIN solapamientos
INSERT INTO reservas (id_usuario, id_recurso, fecha, hora_inicio, hora_fin, estado) VALUES
(2, 1, '2026-06-05', '09:00', '11:00', 'confirmada'), -- Daniel reserva Aula 1
(3, 3, '2026-06-05', '10:00', '11:00', 'pendiente'), -- Laura reserva Sala A
(4, 7, '2026-06-05', '18:00', '19:00', 'confirmada'), -- Carlos reserva Pista de pádel
(2, 5, '2026-06-06', '12:00', '13:00', 'pendiente'); -- Daniel reserva portátil HP


-- ============================================================
--  ÍNDICES
-- ============================================================

CREATE INDEX idx_reserva_recurso_fecha ON reservas(id_recurso, fecha);
CREATE INDEX idx_reserva_usuario_fecha ON reservas(id_usuario, fecha);


-- ============================================================
--  TRIGGER ANTISOLAPAMIENTO
-- ============================================================

DELIMITER $$

CREATE TRIGGER evitar_solapamiento
BEFORE INSERT ON reservas
FOR EACH ROW
BEGIN
    IF EXISTS (
        SELECT 1 FROM reservas
        WHERE id_recurso = NEW.id_recurso
        AND fecha = NEW.fecha
        AND (
            (NEW.hora_inicio BETWEEN hora_inicio AND hora_fin)
            OR
            (NEW.hora_fin BETWEEN hora_inicio AND hora_fin)
            OR
            (hora_inicio BETWEEN NEW.hora_inicio AND NEW.hora_fin)
        )
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Error: El recurso ya está reservado en ese horario.';
    END IF;
END$$

DELIMITER ;







-- ============================================================
--  VISTA: RESERVAS DEL DÍA
-- ============================================================

CREATE VIEW reservas_hoy AS
SELECT r.id_reserva, u.nombre AS usuario, rc.nombre AS recurso,
       r.fecha, r.hora_inicio, r.hora_fin, r.estado
FROM reservas r
JOIN usuarios u ON r.id_usuario = u.id_usuario
JOIN recursos rc ON r.id_recurso = rc.id_recurso
WHERE r.fecha = CURDATE();


-- ============================================================
--  PROCEDIMIENTO ALMACENADO
-- ============================================================

DELIMITER $$

CREATE PROCEDURE crear_reserva(
    IN p_usuario INT,
    IN p_recurso INT,
    IN p_fecha DATE,
    IN p_inicio TIME,
    IN p_fin TIME
)
BEGIN
    INSERT INTO reservas(id_usuario, id_recurso, fecha, hora_inicio, hora_fin)
    VALUES (p_usuario, p_recurso, p_fecha, p_inicio, p_fin);
END$$

DELIMITER ;


-- ============================================================
--  USUARIOS MYSQL
-- ============================================================

CREATE USER 'admin_app'@'localhost' IDENTIFIED BY 'admin123';
GRANT ALL PRIVILEGES ON sistema_reservas.* TO 'admin_app'@'localhost';

CREATE USER 'usuario_app'@'localhost' IDENTIFIED BY 'user123';
GRANT SELECT, INSERT, UPDATE, EXECUTE, DELETE ON sistema_reservas.* TO 'usuario_app'@'localhost';
