<?php
session_start();
if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit();
}
if ($_SESSION["rol"] != "admin") {
    die("Acceso denegado");
}
include "conexion.php";

$sql = "SELECT * FROM categorias ORDER BY nombre";
$result = $conn->query($sql);

$titulo = "Categorías";
include "includes/header.php";
?>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <h2 class="mb-0 fw-bold"><i class="bi bi-tags me-2 text-primary"></i>Categorías</h2>
    <a href="categoria_nueva.php" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i>Nueva categoría
    </a>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Nombre</th>
                        <th class="d-none d-md-table-cell">Descripción</th>
                        <th class="text-end">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td class="text-muted"><?php echo $row["id_categoria"]; ?></td>
                            <td class="fw-semibold"><?php echo htmlspecialchars($row["nombre"]); ?></td>
                            <td class="d-none d-md-table-cell text-muted"><?php echo htmlspecialchars($row["descripcion"]); ?></td>
                            <td class="text-end">
                                <a href="categoria_editar.php?id=<?php echo $row["id_categoria"]; ?>"
                                    class="btn btn-sm btn-outline-primary me-1">
                                    <i class="bi bi-pencil"></i><span class="d-none d-sm-inline ms-1">Editar</span>
                                </a>
                                <a href="categoria_eliminar.php?id=<?php echo $row["id_categoria"]; ?>"
                                    class="btn btn-sm btn-outline-danger"
                                    onclick="return confirm('¿Seguro que deseas eliminar esta categoría?');">
                                    <i class="bi bi-trash"></i><span class="d-none d-sm-inline ms-1">Eliminar</span>
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include "includes/footer.php"; ?>