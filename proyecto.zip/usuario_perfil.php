<?php
session_start();
if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit();
}

include "conexion.php";
include "includes/header.php";

$id = $_SESSION["id_usuario"];

$sql = "SELECT * FROM usuarios WHERE id_usuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$usuario = $stmt->get_result()->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = trim($_POST["nombre"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    $sql = "UPDATE usuarios SET nombre=?, email=?, password=? WHERE id_usuario=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $nombre, $email, $password, $id);
    $stmt->execute();

    $_SESSION["nombre"] = $nombre;

    $mensaje = "Perfil actualizado correctamente";
}
?>

<h2>Mi perfil</h2>

<?php if (isset($mensaje)): ?>
<div class="alert alert-success"><?= $mensaje ?></div>
<?php endif; ?>

<form method="POST" class="col-md-6">
    <div class="mb-3">
        <label class="form-label">Nombre</label>
        <input type="text" name="nombre" class="form-control" value="<?= $usuario["nombre"] ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-control" value="<?= $usuario["email"] ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Contraseña</label>
        <input type="text" name="password" class="form-control" value="<?= $usuario["password"] ?>" required>
    </div>

    <button class="btn btn-primary">Guardar cambios</button>
</form>

<?php include "includes/footer.php"; ?>
