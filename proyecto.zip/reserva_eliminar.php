<?php
session_start();
if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit();
}
include "conexion.php";

$id_usuario = $_SESSION["id_usuario"];
$rol = $_SESSION["rol"];

if (!isset($_GET["id"])) {
    header("Location: reserva.php");
    exit();
}

$id = (int) $_GET["id"];

$sql = "SELECT * FROM reservas WHERE id_reserva = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$reserva = $result->fetch_assoc();

if (!$reserva) {
    die("Reserva no encontrada");
}

if ($rol != "admin" && $reserva["id_usuario"] != $id_usuario) {
    die("No puedes eliminar esta reserva");
}

$sql = "DELETE FROM reservas WHERE id_reserva = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header("Location: reserva.php");
    exit();
} else {
    die("Error al eliminar la reserva");
}
?>
