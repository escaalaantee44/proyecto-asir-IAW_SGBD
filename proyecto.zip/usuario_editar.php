<?php
session_start();
if (!isset($_SESSION["id_usuario"]) || $_SESSION["rol"] != "admin") {
    header("Location: login.php");
    exit();
}

include "conexion.php";
include "includes/header.php";

$id = $_GET["id"];

$sql = "SELECT * FROM usuarios WHERE id_usuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$usuario = $stmt->get_result()->fetch_assoc();

if (!$usuario) die("Usuario no encontrado");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = trim($_POST["nombre"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
    $rol = $_POST["rol"];

    $sql = "UPDATE usuarios SET nombre=?, email=?, password=?, rol=? WHERE id_usuario=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $nombre, $email, $password, $rol, $id);
    $stmt->execute();

    header("Location: usuarios.php");
    exit();
}
?>

<h2>Editar usuario</h2>
<a href="usuarios.php" class="btn btn-secondary mb-3">Volver</a>

<form method="POST" class="col-md-6">
    <div class="mb-3">
        <label class="form-label">Nombre</label>
        <input type="text" name="nombre" class="form-control" value="<?= $usuario["nombre"] ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-control" value="<?= $usuario["email"] ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Contraseña</label>
        <input type="text" name="password" class="form-control" value="<?= $usuario["password"] ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Rol</label>
        <select name="rol" class="form-select">
            <option value="usuario" <?= $usuario["rol"]=="usuario"?"selected":"" ?>>Usuario</option>
            <option value="admin" <?= $usuario["rol"]=="admin"?"selected":"" ?>>Administrador</option>
        </select>
    </div>

    <button class="btn btn-primary">Guardar cambios</button>
</form>

<?php include "includes/footer.php"; ?>
