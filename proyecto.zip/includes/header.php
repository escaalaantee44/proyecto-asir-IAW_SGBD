<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo isset($titulo) ? htmlspecialchars($titulo) : 'Sistema de Reservas'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .navbar-brand {
            font-weight: 700;
            letter-spacing: 0.5px;
        }

        .card {
            border: none;
            box-shadow: 0 2px 8px rgba(0, 0, 0, .08);
            border-radius: 12px;
        }

        .card-header {
            border-radius: 12px 12px 0 0 !important;
            font-weight: 600;
        }

        .table th {
            font-size: .85rem;
            text-transform: uppercase;
            letter-spacing: .5px;
            color: #6c757d;
        }

        .btn {
            border-radius: 8px;
        }

        .badge {
            font-size: .78rem;
        }

        footer {
            font-size: .8rem;
            color: #adb5bd;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-calendar2-check me-2"></i>Sistema de Reservas
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <?php if (isset($_SESSION["id_usuario"])): ?>
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php"><i class="bi bi-house me-1"></i>Panel</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="reserva.php"><i class="bi bi-calendar3 me-1"></i>Reservas</a>
                        </li>
                        <?php if (isset($_SESSION["rol"]) && $_SESSION["rol"] == "admin"): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="categorias.php"><i class="bi bi-tags me-1"></i>Categorías</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <span class="nav-link text-white-50">
                                <a href="usuario_perfil.php" class="bi bi-person-circle me-1"><?php echo htmlspecialchars($_SESSION["nombre"]); ?></a>
                            </span>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php"><i class="bi bi-box-arrow-right me-1"></i>Salir</a>
                        </li>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    <div class="container py-4">