</div><!-- /container -->
<footer class="text-center py-4 mt-4 border-top">
    <p class="mb-0"><i class="bi bi-calendar2-check me-1"></i>Sistema de Reservas &copy; <?php echo date('Y'); ?></p>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>