<?php
session_start();
if (!isset($_SESSION["id_usuario"]) || $_SESSION["rol"] != "admin") {
    header("Location: login.php");
    exit();
}

include "conexion.php";
include "includes/header.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = trim($_POST["nombre"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
    $rol = $_POST["rol"];

    if ($nombre == "" || $email == "" || $password == "") {
        $error = "Todos los campos son obligatorios";
    } else {
        $sql = "INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $nombre, $email, $password, $rol);

        if ($stmt->execute()) {
            header("Location: usuarios.php");
            exit();
        } else {
            $error = "Error al crear usuario";
        }
    }
}
?>

<h2>Nuevo usuario</h2>
<a href="usuarios.php" class="btn btn-secondary mb-3">Volver</a>

<?php if (isset($error)): ?>
<div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<form method="POST" class="col-md-6">
    <div class="mb-3">
        <label class="form-label">Nombre</label>
        <input type="text" name="nombre" class="form-control" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-control" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Contraseña</label>
        <input type="password" name="password" class="form-control" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Rol</label>
        <select name="rol" class="form-select">
            <option value="usuario">Usuario</option>
            <option value="admin">Administrador</option>
        </select>
    </div>

    <button class="btn btn-primary">Crear usuario</button>
</form>

<?php include "includes/footer.php"; ?>
