<?php
session_start();
if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit();
}
if ($_SESSION["rol"] != "admin") {
    die("Acceso denegado");
}
include "conexion.php";
include "includes/header.php";

$sql = "SELECT r.*, c.nombre AS categoria
        FROM recursos r
        JOIN categorias c ON r.id_categoria = c.id_categoria
        ORDER BY c.nombre, r.nombre";
$result = $conn->query($sql);
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Recursos</h2>
    <a href="recurso_nuevo.php" class="btn btn-success">Nuevo recurso</a>
</div>

<a href="index.php" class="btn btn-secondary mb-3">Volver al panel</a>

<table class="table table-striped table-hover">
    <thead class="table-dark">
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Categoría</th>
            <th>Capacidad</th>
            <th>Estado</th>
            <th style="width: 150px;">Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row["id_recurso"]; ?></td>
            <td><?php echo htmlspecialchars($row["nombre"]); ?></td>
            <td><?php echo htmlspecialchars($row["categoria"]); ?></td>
            <td><?php echo $row["capacidad"]; ?></td>
            <td><?php echo $row["estado"]; ?></td>
            <td>
                <a href="recurso_editar.php?id=<?php echo $row["id_recurso"]; ?>" class="btn btn-warning btn-sm">Editar</a>
                <a href="recurso_eliminar.php?id=<?php echo $row["id_recurso"]; ?>"
                   class="btn btn-danger btn-sm"
                   onclick="return confirm('¿Seguro que deseas eliminar este recurso?');">
                   Eliminar
                </a>
            </td>
        </tr>
        <?php } ?>
    </tbody>
</table>

<?php include "includes/footer.php"; ?>
