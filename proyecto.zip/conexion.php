<?php

$host = "localhost";
$db   = "sistema_reservas";
 
if (isset($_SESSION["rol"]) && $_SESSION["rol"] == "admin") {
    $user = "admin_app";
    $pass = "admin123";
} else {
    $user = "usuario_app";
    $pass = "user123";
}
 
$conn = new mysqli($host, $user, $pass, $db);
 
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
 
$conn->set_charset("utf8");
