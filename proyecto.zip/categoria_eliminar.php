<?php
session_start();
if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit();
}
if ($_SESSION["rol"] != "admin") {
    die("Acceso denegado");
}
include "conexion.php";

if (!isset($_GET["id"])) {
    header("Location: categorias.php");
    exit();
}

$id = (int) $_GET["id"];

$sql = "DELETE FROM categorias WHERE id_categoria = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header("Location: categorias.php");
    exit();
} else {
    die("No se pudo eliminar la categoría. Es posible que tenga recursos asociados.");
}
