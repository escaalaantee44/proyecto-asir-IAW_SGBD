<?php
session_start();
if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit();
}
if ($_SESSION["rol"] != "admin") {
    die("Acceso denegado");
}

include "conexion.php";
include "includes/header.php";

$sql = "SELECT * FROM usuarios ORDER BY rol, nombre";
$result = $conn->query($sql);
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Gestión de usuarios</h2>
    <a href="usuario_nuevo.php" class="btn btn-success">Nuevo usuario</a>
</div>

<a href="index.php" class="btn btn-secondary mb-3">Volver</a>

<table class="table table-striped table-hover">
    <thead class="table-dark">
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Email</th>
            <th>Rol</th>
            <th style="width:150px;">Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($u = $result->fetch_assoc()) { ?>
        <tr>
            <td><?= $u["id_usuario"] ?></td>
            <td><?= htmlspecialchars($u["nombre"]) ?></td>
            <td><?= htmlspecialchars($u["email"]) ?></td>
            <td><?= $u["rol"] ?></td>
            <td>
                <a href="usuario_editar.php?id=<?= $u["id_usuario"] ?>" class="btn btn-warning btn-sm">Editar</a>
                <a href="usuario_eliminar.php?id=<?= $u["id_usuario"] ?>" 
                   class="btn btn-danger btn-sm"
                   onclick="return confirm('¿Eliminar este usuario?')">
                   Eliminar
                </a>
            </td>
        </tr>
        <?php } ?>
    </tbody>
</table>

<?php include "includes/footer.php"; ?>
s